package services;

import models.Car;
import models.Renter;
import models.RentalSession;
import java.util.HashMap;
import java.util.Map;

public class RentalService {
    private Map<String, RentalSession> rentalSessions = new HashMap<>();

    public void startRental(String carId, Car car, Renter renter, double speedLimit) {
        rentalSessions.put(carId, new RentalSession(car, renter, speedLimit));
    }

    public RentalSession getRentalSession(String carId) {
        return rentalSessions.get(carId);
    }
}
