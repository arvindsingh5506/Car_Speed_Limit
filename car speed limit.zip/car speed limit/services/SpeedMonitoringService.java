package services;

import models.SpeedEvent;
import models.RentalSession;
import services.NotificationService;
import services.RentalService;

public class SpeedMonitoringService {
    private RentalService rentalService;
    private NotificationService notificationService;

    public SpeedMonitoringService(RentalService rentalService, NotificationService notificationService) {
        this.rentalService = rentalService;
        this.notificationService = notificationService;
    }

    public void processSpeedEvent(SpeedEvent event) {
        RentalSession session = rentalService.getRentalSession(event.getCarId());
        
        if (session != null && event.getSpeed() > session.getMaxSpeedLimit()) {
            notificationService.sendNotification(session, event.getSpeed());
        }
    }
}
