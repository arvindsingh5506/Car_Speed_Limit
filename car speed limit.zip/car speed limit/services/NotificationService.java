package services;

import models.RentalSession;

public class NotificationService {

    public void sendNotification(RentalSession session, double speed) {
        String message = "ALERT: Renter " + session.getRenter().getName() +
                " exceeded speed limit of " + session.getMaxSpeedLimit() + " km/h. Current speed: " + speed + " km/h.";
        
        // Simulated Firebase notification
        System.out.println("Sending Firebase notification: " + message);

        // Placeholder for AWS alternative
        // System.out.println("Sending AWS SNS notification: " + message);
    }
}
