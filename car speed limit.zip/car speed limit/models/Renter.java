package models;

public class Renter {
    private String id;
    private String name;


    public Renter(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() { return id; }
    public String getName() { return name; }
}
