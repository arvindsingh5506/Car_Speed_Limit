package models;

public class RentalSession {
    private Car car;
    private Renter renter;
    private double maxSpeedLimit;

    public RentalSession(Car car, Renter renter, double maxSpeedLimit) {
        this.car = car;
        this.renter = renter;
        this.maxSpeedLimit = maxSpeedLimit;
    }

    public Car getCar() { return car; }
    public Renter getRenter() { return renter; }
    public double getMaxSpeedLimit() { return maxSpeedLimit; }
}
