package models;

public class SpeedEvent {
    private String carId;
    private double speed;

    public SpeedEvent(String carId, double speed) {
        this.carId = carId;
        this.speed = speed;
    }

    public String getCarId() { return carId; }
    public double getSpeed() { return speed; }
}
