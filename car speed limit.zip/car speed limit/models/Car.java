package models;

public class Car {
    private String id;
    private String model;

    public Car(String id, String model) {
        this.id = id;
        this.model = model;
    }

    public String getId() { return id; }
    public String getModel() { return model; }
}
