import models.*;
import services.*;
import services.RentalService;



public class Main {
    public static void main(String[] args) {
        // Initialize services
        RentalService rentalService = new RentalService();
        NotificationService notificationService = new NotificationService();
        SpeedMonitoringService speedMonitoringService = new SpeedMonitoringService(rentalService, notificationService);

        Car car = new Car("CAR123", "Toyota Corolla");
        Renter renter = new Renter("USER1", "John Doe");


        rentalService.startRental(car.getId(), car, renter, 80.0);


        speedMonitoringService.processSpeedEvent(new SpeedEvent("CAR123", 75.0)); // Below limit (no alert)
        speedMonitoringService.processSpeedEvent(new SpeedEvent("CAR123", 85.0)); // Above limit (alert triggered)
    }
}
